package com.mentorama.hospitalapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
